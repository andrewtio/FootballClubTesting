package com.andrew.associate.footballclub.model

data class TeamResponse (
    val teams: List<Team>
)